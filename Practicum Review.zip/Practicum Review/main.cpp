//colton gardner
//08/29/17
//dge 300 practicum 00: o-o review

#include <iostream>
#include <vector>

class Employee {
    public:
        virtual std::string getName() const = 0;
        virtual int getPay() const = 0;
};

class SalariedEmployee: public Employee {
    private:
        std::string m_name;
        int m_salary;
    public:
        SalariedEmployee(std::string name, int salary) : m_name(name), m_salary(salary) {}
        virtual std::string getName() const { return m_name; }
        virtual int getPay() const { return m_salary; }
};

class HourlyEmployee: public Employee {
    private:
        std::string m_name;
        int m_hours,
            m_rate;
    public:
        HourlyEmployee(std::string name, int hours, int rate) : m_name(name), m_hours(hours), m_rate(rate) {}
        virtual std::string getName() const { return m_name; }
        virtual int getPay() const { return m_hours*m_rate; }
};

int main()
{
        std::vector <Employee*> myEmployees;

        myEmployees.push_back(new SalariedEmployee("Gardner", 100000));
        myEmployees.push_back(new SalariedEmployee("Bale", 70000));
        myEmployees.push_back(new HourlyEmployee("Buscemi", 40, 25));
        myEmployees.push_back(new HourlyEmployee("McConaughey", 40, 30));

        for (int i = 0; myEmployees.size(); i++)
            {
                std::cout << myEmployees[i]->getName() << " " << myEmployees[i]->getPay() << std::endl;
            }
    return 0;
}
